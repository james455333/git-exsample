package jason;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.tools.DocumentationTool.Location;

import org.json.*;

public class JsonTest {

	public static void main(String[] args) throws ParseException {
		File file = new File("C:\\JavaWorkspace\\ForTest\\src\\jason\\jsonTest/test002.json");
		File file1 = new File("C:\\JavaWorkspace\\ForTest\\src\\jason\\jsonTest/test001.json");
		
		
		try (
//				FileInputStream fis = new FileInputStream(file);
				FileInputStream fis = new FileInputStream(file1); //具有陣列的檔案，本資料量大太時執行印出會造成LAG 慎用
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
				){
			
			//先將檔案讀取成一個字串，資料量大時請使用StringBuilder增加效率
			
			String str = null;
//			String data = "";
//			while ((str = br.readLine())!=null) {
//				data = data + str;
//			}
			
			//StringBuilder用法
			StringBuilder sb = new StringBuilder();
			while ((str = br.readLine())!=null) {
				sb.append(str);
			}
			String data = sb.toString(); //使用StringBuilder記得要再轉成String型態才能轉換為JSON物件
			
			
//			System.out.println(data);
			
			
			
		//方法一 根據JSON內的物件名稱用get("keyName")抓取成物件，再用toString()把抓取到的物件轉換為JSON物件
			//先將抓取來的String轉換成JSONObject
			JSONObject test1File = new JSONObject(data);
			//抓取根物件 名稱為 cwbopendata
			Object t1 = test1File.get("cwbopendata");
			//這時候 t1還只是物件，雖然內容正確，但不是"JSON物件"，還不能使用JSON物件的方法
			System.out.println(t1);
//			t1.get("dataset") //尚未轉成JSON物件而無法使用

			//將Obeject 用toString()轉換成字串，才可以作為參數做成新的JSON物件
			JSONObject cwbopendata = new JSONObject(t1.toString());
			System.out.println(cwbopendata);
			
			//以此類推 可以簡化成 JasonObject.get("key name").toString()
			JSONObject dataSet = new JSONObject(cwbopendata.get("dataset").toString());
//			System.out.println(dataSet);
			JSONObject resource = new JSONObject(dataSet.get("resource").toString());
			//注意! 此例中，resource已經是"dataset"的最後一個型態，裡面存放可能是Array也可能是該物件的屬性(name)與值(value)
			//此例中resource裡面存放的是該物件的屬性(Field)與值(Value)
			System.out.println(resource);
			
			//存取物件屬性的方法 Object.get("Field") 如下：
			Object resourceDesc_Obeject = resource.get("resourceDesc");
			String resourceDesc_String = (String) resource.get("resourceDesc");
			//上面兩者印出的表現是相同的，但根據需要，可以強制轉型為String
			
			System.out.println("resourceDesc_Obeject : " + resourceDesc_Obeject);
			System.out.println("resourceDesc_String : " + resourceDesc_String);
			
			String mimeType = (String)resource.get("mimeType");
			System.out.println("mimeType : " + mimeType);
			String uri = (String)resource.get("uri");
			System.out.println("uri : " + uri);    
			
			
		//方法二 根據物件名稱直接抓取指定物件為JSONObject 但必須熟知結構與物件名稱
//			JSONObject test1File = new JSONObject(data);
//			JSONObject dataset = test1File.getJSONObject("cwbopendata").getJSONObject("dataset");
//			System.out.println("dataset : " +dataset);
			
			
		//日期獲取與轉換如:test001內的資料日期並轉換為需要的格式
//			JSONObject test1File = new JSONObject(data);
//			JSONObject cwbopendata = test1File.getJSONObject("cwbopendata");
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//			Date parse = sdf.parse(cwbopendata.get("sent").toString());
//			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			String format = sdf2.format(parse);
//			System.out.println(format);

			
			
		//有些資料內會有Array來包裹 使用
//			//如test002.xml中 要抓取臺北市1/1的月出時刻的資料
//			JSONObject test002 = new JSONObject(data);
//			JSONObject locations = test002.getJSONObject("cwbopendata").getJSONObject("dataset").getJSONObject("locations");
//			
//			//此時 locations裡的資料為    { "location":[...] }
//			//而location為Array，因此使用JSONArray
//			JSONArray location = locations.getJSONArray("location");
//			
//			//抓取到這裡時location裡面含有的資料為{ { "locationName" : "臺北市" , "time" : [...]},{"locationName" : "新北市" , "time" : [...]},...}
//			for (int i = 0; i < location.length(); i++) { //Aarry個別抓取方法 for迴圈
//				JSONObject locationF = new JSONObject(location.get(i).toString());
//				
//				
//				//locationF的"locatoinName"為"臺北市"時，抓取 locationF的"time",而time為Array，因此使用JSONArray
//				if (locationF.get("locationName").equals("臺北市")) {
//					JSONArray taipeiTime = locationF.getJSONArray("time");
//					
//					// 此時 taipeiTime裡面的資料為 [ { "dataTime" : "2020-01-01", "parameter" : [...] },{ "dataTime" : "2020-01-02", "parameter" : [...] }, ...]
//					for (int j = 0; j < taipeiTime.length(); j++) { 
//						JSONObject date = new JSONObject(taipeiTime.get(j).toString());
//						
//						// taipeiTime的 "dataTime"如果是 "2020-01-01",抓取taipeiTime的"parameter"，而"parameter"為Array，因此使用JSONArray
//						if (date.get("dataTime").equals("2020-01-01")) {
//							JSONArray parameter = date.getJSONArray("parameter");
//							
//							// 此時 parameter 裡面的資料為 [ {"parameterName": "月出時刻","parameterValue": "10:53"},{"parameterName": "方位角","parameterValue": "100"},{...}... ]
//							for (int k = 0; k < parameter.length(); k++) {
//								JSONObject parameters = new JSONObject(parameter.get(k).toString());
//								if (parameters.get("parameterName").equals("月出時刻")) {
//									System.out.println( parameters.get("parameterName") + " : " + parameters.getString("parameterValue") );
//									
//									
//								}
//							}
//						}
//					}
//				}
//			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
//	    System.out.println(jo.get("abc"));
		
		

	}

}
