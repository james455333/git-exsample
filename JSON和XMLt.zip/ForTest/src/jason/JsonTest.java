package jason;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.*;

public class JsonTest {

	public static void main(String[] args) {
		File file = new File("C:\\JavaWorkspace\\ForTest\\src\\jason\\jsonTest/test002.json");
		
		
//		try (
//				FileInputStream fis = new FileInputStream(file);
//				InputStreamReader isr = new InputStreamReader(fis);
//				BufferedReader br = new BufferedReader(isr);
//				){
//			String str = null;
//			String data = "";
//			while ((str = br.readLine())!=null) {
//				data = data + str + "\n";
//			}
//			
			
//			System.out.println(test1File.getJSONObject("cwbopendata"));
			
			
			//方法一 根據欄位名稱用get("keyName")抓取成物件，再用toString()把抓取到的物件轉換為JSON物件
//			JSONObject test1File = new JSONObject(data);
//			Object t1 = test1File.get("cwbopendata");
//			JSONObject cwbopendata = new JSONObject(t1.toString());
//			System.out.println(cwbopendata);
//			JSONObject dataSet = new JSONObject(cwbopendata.get("dataset").toString());
//			System.out.println(dataSet);
//			JSONObject resource = new JSONObject(dataSet.get("resource").toString());
//			System.out.println(resource);
			//方法二 根據欄位名稱直接抓取JSONObject 但必須熟知結構與欄位名稱
//			JSONObject test1File = new JSONObject(data);
//			JSONObject dataset = test1File.getJSONObject("cwbopendata").getJSONObject("dataset");
//			System.out.println("dataset : " +dataset);
			
			//如:獲取JSON內的資料日期並轉換為需要的格式
//			JSONObject test1File = new JSONObject(data);
//			JSONObject cwbopendata = test1File.getJSONObject("cwbopendata");
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//			Date parse = sdf.parse(cwbopendata.get("sent").toString());
//			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			String format = sdf2.format(parse);
//			System.out.println(format);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
//	    System.out.println(jo.get("abc"));
		
		

	}

}
