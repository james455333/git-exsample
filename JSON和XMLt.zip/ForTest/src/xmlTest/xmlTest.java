package xmlTest;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.dom4j.*;
import org.dom4j.io.SAXReader;

public class xmlTest {
	public static void main(String[] args) {
		
		File file = new File("C:\\JavaWorkspace\\ForTest/F-B0053-001.xml");
		SAXReader reader = new SAXReader();
		try {
			Document document = reader.read(file);
			List<Node> selectNodes = document.selectNodes("/cwbopendata/identifier");
			
			
			
			//方法一 迭代抓取
			
			//從文件中抓取根元素
//			Element root = document.getRootElement();
//			System.out.println(root.getName());
	
			//第一層子元素 elementIterator("dataset")為指定抓取名為dataset的子元素
//			for (Iterator<Element> it = root.elementIterator("dataset"); it.hasNext();) {
//				Element foo = it.next();
////				System.out.println(foo.getData());
//				//第一層子元素的子元素(第二層)
//				for (Iterator<Element> it2 = foo.elementIterator("datasetInfo"); it2.hasNext();) {
//					Element ele = it2.next();
////					System.out.println(ele.getData());
//					//第二層子元素的子元素(第三層)
//					for (Iterator<Element> it3 = ele.elementIterator("validTime"); it3.hasNext();) {
////						Element ele2 = it3.next();
//						Element next = it3.next();
//						String name = next.getName();
//						if(name.equals("")) {
//							next.getData()
//						}
////						Object data = ele2.getData();
////						System.out.println(data.toString());
////						//第三層子元素的子元素(第四層)
//////						for (Iterator<Element> it4 = ele2.elementIterator(); it4.hasNext();) {
//////							Element ele3 = it4.next();
//////							System.out.println(ele3.getData());
//////						}
//					}
//				}
//			}
			
			
		
		
		
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
