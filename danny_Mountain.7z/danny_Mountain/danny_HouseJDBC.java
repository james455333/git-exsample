package danny_Mountain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

public class danny_HouseJDBC implements danny_HouseDAO {

private DataSource dataSource;

	
	public DataSource getDataSource() {
		if (dataSource == null) {
			BasicDataSource ds = new BasicDataSource();
			ds.setDriverClassName("oracle.jdbc.OracleDriver");
			ds.setUrl("jdbc:oracle:thin:@//localhost:1521/XEPDB1");
			ds.setUsername("HI");
			ds.setPassword("HI");
			ds.setMaxTotal(50); // 設定最多connection上線,超過使用量必須等待
			ds.setMaxIdle(50);

			dataSource = ds;// 把BasicDataSource放在屬性上
		}
		return dataSource;
	}
	@Override
	public List<danny_House> listMH(){
		List<danny_House> list =new ArrayList<>();
		
		
		
		try (Connection connection = getDataSource().getConnection();
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("select*from mountainhouse");
				) {
		
			
			while(rs.next()) {
			danny_House hs =new danny_House();
			
			hs.setMountainname(rs.getString("mountainname"));
			hs.setName(rs.getString("name"));
			hs.setSeat(rs.getInt("seat"));
			hs.setCampseat(rs.getInt("campseat"));
			hs.setHight(rs.getString("hight"));
			list.add(hs);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	
	@Override
	public List<danny_House> selectMountain(){
		List<danny_House> list =new ArrayList<>();
		
		String mth;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("山頭");
		mth = scanner.nextLine();
		
		
		
		try (Connection connection = getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("select*from mountainhouse where mountainname=?");
//				ResultSet rs = stmt.executeQuery("select*from Camp where city=?");
				) {
			
			
			
			stmt.setString(1, mth);
			ResultSet rs=stmt.executeQuery();
		
			while(rs.next()) {
				danny_House hs =new danny_House();
				
				hs.setMountainname(rs.getString("mountainname"));
				hs.setName(rs.getString("name"));
				hs.setSeat(rs.getInt("seat"));
				hs.setCampseat(rs.getInt("campseat"));
				hs.setHight(rs.getString("hight"));
				list.add(hs);
			
			
			}
			
			if (mth.equals("1")) {
				
			}else if(mth=="2"){
				
			}
			
			
			
			
			
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	
	@Override
	public List<danny_House> selectName(){
		List<danny_House> list =new ArrayList<>();
		
		String n;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("名字");
		n = scanner.nextLine();
		
		try (Connection connection = getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("select*from mountainhouse where name=?");
//				ResultSet rs = stmt.executeQuery("select*from Camp where city=?");
				) {
			stmt.setString(1, n);
			ResultSet rs=stmt.executeQuery();
		
			while(rs.next()) {
				danny_House hs =new danny_House();
				
				hs.setMountainname(rs.getString("mountainname"));
				hs.setName(rs.getString("name"));
				hs.setSeat(rs.getInt("seat"));
				hs.setCampseat(rs.getInt("campseat"));
				hs.setHight(rs.getString("hight"));
				list.add(hs);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
}
