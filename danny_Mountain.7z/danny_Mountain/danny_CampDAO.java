package danny_Mountain;

import java.util.List;

public interface danny_CampDAO {

	List<danny_Camp> listCamps();

	List<danny_Camp> selectCity();

	List<danny_Camp> selectTown();

	List<danny_Camp> selectName();

}