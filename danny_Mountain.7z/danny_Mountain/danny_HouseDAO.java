package danny_Mountain;

import java.util.List;

public interface danny_HouseDAO {

	List<danny_House> listMH();

	List<danny_House> selectMountain();

	List<danny_House> selectName();

}