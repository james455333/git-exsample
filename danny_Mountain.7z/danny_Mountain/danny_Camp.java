package danny_Mountain;

public class danny_Camp {
	private	String	city;
	private	String	camptown;
	private	String	campname;
	private	String	campdesc;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city=city;
	}
	
	public String getCamptown() {
		return camptown;
	}
	public void setCamptown(String camptown) {
		this.camptown=camptown;
	}
	
	public String getCampname() {
		return campname;
	}
	public void setCampname(String campname) {
		this.campname=campname;
	}
	
	public String getCampdesc() {
		return campdesc;
	}
	public void setCampdesc(String campdesc) {
		this.campdesc=campdesc;
	}
	
	
	
	
}
