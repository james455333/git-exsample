package danny_Mountain;

public class danny_House {

	private	String	mountainname;
	private	String	name;
	private int	seat;
	private int	campseat;
	private	String	hight;
	
	public String getMountainname() {
		return mountainname;
	}
	public void setMountainname(String mountainname) {
		this.mountainname=mountainname;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat=seat;
	}
	
	public int getCampseat() {
		return campseat;
	}
	public void setCampseat(int campseat) {
		this.campseat=campseat;
	}
	
	public String getHight() {
		return hight;
	}
	public void setHight(String hight) {
		this.hight=hight;
	}	
}
