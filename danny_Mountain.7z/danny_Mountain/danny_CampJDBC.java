package danny_Mountain;

import java.util.List;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

public class danny_CampJDBC implements  danny_CampDAO{
	
private DataSource dataSource;

	
	public DataSource getDataSource() {
		if (dataSource == null) {
			BasicDataSource ds = new BasicDataSource();
			ds.setDriverClassName("oracle.jdbc.OracleDriver");
			ds.setUrl("jdbc:oracle:thin:@//localhost:1521/XEPDB1");
			ds.setUsername("HI");
			ds.setPassword("HI");
			ds.setMaxTotal(50); // 設定最多connection上線,超過使用量必須等待
			ds.setMaxIdle(50);

			dataSource = ds;// 把BasicDataSource放在屬性上
		}
		return dataSource;
	}
	

	@Override
	public List<danny_Camp> listCamps(){
		List<danny_Camp> list =new ArrayList<>();
		
		
		
		try (Connection connection = getDataSource().getConnection();
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("select*from Camp ");
				) {
		
			
			while(rs.next()) {
			danny_Camp cmp =new danny_Camp();
			
			cmp.setCity(rs.getString("city"));
			cmp.setCamptown(rs.getString("camptown"));
			cmp.setCampname(rs.getString("campname"));
			cmp.setCampdesc(rs.getString("campdesc"));
			list.add(cmp);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	
	@Override
	public List<danny_Camp> selectCity(){
		List<danny_Camp> list =new ArrayList<>();
		
		String ct1;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("縣市");
		ct1 = scanner.nextLine();
		
		try (Connection connection = getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("select*from Camp where city=?");
//				ResultSet rs = stmt.executeQuery("select*from Camp where city=?");
				) {
			stmt.setString(1, ct1);
			ResultSet rs=stmt.executeQuery();
		
			while(rs.next()) {
			danny_Camp cmp =new danny_Camp();
			
			cmp.setCity(rs.getString("city"));
			cmp.setCamptown(rs.getString("camptown"));
			cmp.setCampname(rs.getString("campname"));
			cmp.setCampdesc(rs.getString("campdesc"));
			list.add(cmp);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	
	
	@Override
	public List<danny_Camp> selectTown(){
		List<danny_Camp> list =new ArrayList<>();
		
		String cmpt;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("鄉鎮");
		cmpt = scanner.nextLine();
		
		try (Connection connection = getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("select*from Camp where camptown=?");
//				ResultSet rs = stmt.executeQuery("select*from Camp where city=?");
				) {
			stmt.setString(1, cmpt);
			ResultSet rs=stmt.executeQuery();
		
			while(rs.next()) {
			danny_Camp cmp =new danny_Camp();
			
			cmp.setCity(rs.getString("city"));
			cmp.setCamptown(rs.getString("camptown"));
			cmp.setCampname(rs.getString("campname"));
			cmp.setCampdesc(rs.getString("campdesc"));
			list.add(cmp);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	@Override
	public List<danny_Camp> selectName(){
		List<danny_Camp> list =new ArrayList<>();
		
		String cmpn;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("鄉鎮");
		cmpn = scanner.nextLine();
		
		try (Connection connection = getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("select*from Camp where campname=?");
//				ResultSet rs = stmt.executeQuery("select*from Camp where city=?");
				) {
			stmt.setString(1, cmpn);
			ResultSet rs=stmt.executeQuery();
		
			while(rs.next()) {
			danny_Camp cmp =new danny_Camp();
			
			cmp.setCity(rs.getString("city"));
			cmp.setCamptown(rs.getString("camptown"));
			cmp.setCampname(rs.getString("campname"));
			cmp.setCampdesc(rs.getString("campdesc"));
			list.add(cmp);
			
			
			}
			}catch (SQLException e) {
				e.printStackTrace();
	}
	return list;
	}
	
	
	
	
	
	


	
		
	}

