package danny_Mountain;

import java.util.List;
import java.util.Scanner;

public class danny_HouseTeseRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j ;
		danny_House hs=new danny_House();
		Scanner scanner=new Scanner(System.in);
		danny_HouseDAO houseDAO=new danny_HouseJDBC();
		System.out.println("1.觀看"+","+"2.查詢");
		i=scanner.nextInt();
		

		while (i!=0) {
			if (i==1) {
				List<danny_House> list=houseDAO.listMH();
				for (danny_House house:list) {
					System.out.println(house.getMountainname()+","+house.getName()+","+house.getSeat()+","+house.getCampseat()+","+house.getHight());
				}
				System.out.println("1.觀看"+","+"2.查詢");
				i=scanner.nextInt();
			}
			
			if(i==2) {System.out.println("1.山頭"+","+"2.名字");
				j=scanner.nextInt();
				if (j==1) {
					
				List<danny_House> list=houseDAO.selectMountain();
				for (danny_House house:list) {
					System.out.println(house.getMountainname()+" ,"+house.getName()+" ,"+house.getSeat()+" ,"+house.getCampseat()+" ,"+house.getHight());

					}
				}
			
				if (j==2) {
					
					List<danny_House> list=houseDAO.selectName();
					for (danny_House house:list) {
						System.out.println(house.getMountainname()+" ,"+house.getName()+", "+house.getSeat()+", "+house.getCampseat()+" ,"+house.getHight());

					}
				}
		
		
	}

}}}
