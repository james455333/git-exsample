package danny_Mountain;//匯資料庫


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class danny_ReadCamp {

	public static void main(String[] args) {
		
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XEPDB1", "HI", "HI");
				){
			
				File file = new File("C:\\iii\\Camp1.csv");
				try(FileInputStream fis = new FileInputStream(file);
			               BufferedInputStream bf = new BufferedInputStream(fis);
		        		InputStreamReader isr = new InputStreamReader(bf);
		                BufferedReader br = new BufferedReader(isr)){
					String c=null;
					c=br.readLine();
					while((c=br.readLine())!=null) {
					String[] array=c.split(",");
					for(int i=0;i<array.length;i++) {
						System.out.println(array[i]);
					}
					PreparedStatement pstmt=connection.prepareStatement("insert into camp(city,camptown,campname,campdesc)values(?, ?, ?, ?)");
					pstmt.setString(1, array[0]);
                	pstmt.setString(2, array[1]);
                	pstmt.setString(3, array[2]);
                	pstmt.setString(4, array[3]);
                	
                	pstmt.executeUpdate();
                	pstmt.clearParameters();
                	pstmt.close();
					}
					
					
		    
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}}