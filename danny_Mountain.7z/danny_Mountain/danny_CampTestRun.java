package danny_Mountain;

import java.util.List;
import java.util.Scanner;

public class danny_CampTestRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i,j ;
		danny_Camp cmp=new danny_Camp();
		Scanner scanner=new Scanner(System.in);
		danny_CampDAO campDAO=new danny_CampJDBC();
		System.out.println("1.觀看"+","+"2.查詢");
		i=scanner.nextInt();
		

		while (i!=0) {
			if (i==1) {
				List<danny_Camp> list=campDAO.listCamps();
				for (danny_Camp camp:list) {
					System.out.println(camp.getCity()+" "+camp.getCamptown()+" "+camp.getCampname()+" "+camp.getCampdesc());
				}
				System.out.println("1.觀看"+","+"2.查詢");
				i=scanner.nextInt();
			}
			
			if(i==2) {System.out.println("1.縣市"+","+"2.鄉鎮"+","+"3.名字");
				j=scanner.nextInt();
				if (j==1) {
					
				List<danny_Camp> list=campDAO.selectCity();
				for (danny_Camp camp:list) {
					System.out.println(camp.getCity()+" "+camp.getCamptown()+" "+camp.getCampname()+" "+camp.getCampdesc());
				}
			}
			
				if (j==2) {
					
					List<danny_Camp> list=campDAO.selectTown();
					for (danny_Camp camp:list) {
						System.out.println(camp.getCity()+" "+camp.getCamptown()+" "+camp.getCampname()+" "+camp.getCampdesc());
					}
				}
				
				if (j==3) {
					
					List<danny_Camp> list=campDAO.selectName();
					for (danny_Camp camp:list) {
						System.out.println(camp.getCity()+" "+camp.getCamptown()+" "+camp.getCampname()+" "+camp.getCampdesc());
					}
				}
			
		}
		
		
	}

}
}
