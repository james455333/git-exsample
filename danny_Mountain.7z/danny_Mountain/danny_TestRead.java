package danny_Mountain;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Iterator;

import org.omg.CORBA.PUBLIC_MEMBER;

public class danny_TestRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XEPDB1", "HI",
				"HI");) {

			List<String[]> list1 = new ArrayList();

			File file1 = new File("C:\\iii\\town.csv");
			try ( // FileReader fr = new FileReader(file)
					FileInputStream fis1 = new FileInputStream(file1);
					BufferedInputStream bf1 = new BufferedInputStream(fis1);
					InputStreamReader isr1 = new InputStreamReader(bf1);
					BufferedReader br1 = new BufferedReader(isr1)) {
				String b = null;
				b = br1.readLine();
				while ((b = br1.readLine()) != null) {
					String[] array1 = b.split(",");
					if (!list1.contains(array1[0] + array1[1])) {
						list1.add(array1);
//	            		System.out.println(list1);
					}
				}

				List list = new ArrayList();
				File file = new File("C:\\iii\\Camp.csv");
				try ( // FileReader fr = new FileReader(file)
						FileInputStream fis = new FileInputStream(file);
						BufferedInputStream bf = new BufferedInputStream(fis);
						InputStreamReader isr = new InputStreamReader(bf);
						BufferedReader br = new BufferedReader(isr)) {

					String a = null;
					int counter = 0;
					a = br.readLine();
					while ((a = br.readLine()) != null) {
						String[] array = a.split(",");
						String beforeCounties = array[0];
						String beforeLocation = array[1];

						String county = null;
						String location = null;
						for (String[] counties : list1) {
							county = counties[0].substring(1, 3);
							location = counties[1].substring(0, 2);

							if (county.equals(beforeCounties) && location.equals(beforeLocation)) {

								beforeCounties = counties[0];
								beforeLocation = counties[1];

								list.add(beforeCounties + beforeLocation);

								System.out.println(beforeCounties + beforeLocation);
							}

						}

//						PreparedStatement pstmt = connection.prepareStatement("update camp set city=?,camptown=?");
//						pstmt.setString(1, beforeCounties);
//						pstmt.setString(2, beforeLocation);
//						pstmt.executeUpdate();
//						pstmt.close();
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
}
